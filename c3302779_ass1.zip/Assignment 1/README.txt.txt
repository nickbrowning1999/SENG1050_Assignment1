Student Number: c3302779
Name: Nicholas Browning

Files:
index.html
style.css
file1.xml
file2.xml
template.xml